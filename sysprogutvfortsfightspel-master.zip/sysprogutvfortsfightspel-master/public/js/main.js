var game = new Phaser.Game(800, 600, Phaser.AUTO, '', { preload: preload, create: create });

function preload () {
	game.load.image('logo', 'assets/phaser.png');
}

function create () {
	var logo = game.add.sprite(game.world.centerX, game.world.centerY, 'logo');
	logo.anchor.setTo(0.5, 0.5);
}

/*// Sending data to the server "AY".

var someData = prompt("What is your name?", "Your name...");
//window.alert("Welcome!");

var exSocket = new WebSocket("http://46.101.102.50:1337");
exSocket.send(someData);
*/

var socket = io();
